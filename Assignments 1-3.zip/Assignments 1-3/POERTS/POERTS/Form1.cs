﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POERTS
{
    public partial class Form1 : Form
    {
        GameEngine engine = new GameEngine();
        Map map = new Map();

        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = System.DateTime.Now.ToLongTimeString();

            engine.start();

            lblShow.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                   // lblShow.Text += engine.map.grid[i, j] + " ";
                }
            }
            lblShow.Text += "\n";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void lblShow_Click(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;
        }

        private void lblTime_Click(object sender, EventArgs e)
        {

        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            for (int i = 0; i == 20; i++)
            {
                for (int j = 0; j == 20; j++)
                {
                    lblShow.Text += ".";
                }
            }
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            btnSave.Enabled = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result;
            MessageBox.Show("Are you sure you want to exit?", "Exit Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            
            if (result == DialogResult.Yes)
            {
                Application.Exit();
                        
            }
            else
            {
                this.Close();
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            
        }

        private void lblShow_Click_1(object sender, EventArgs e)
        {

        }
    }
}
